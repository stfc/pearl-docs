#! /bin/bash

rm -rf *.run

mpicc -o hello.run hello.c
mpicc -o bandwidth_test.run bandwidth_test.c
mpicc -o mpi_send_rec.run mpi_send_rec.c
